# Change Log

## [2.0.0] 2017-12-11
### Major Release
- update to Bootstrap 4 Beta
- added new icons by Nucleo
- bug fixes and improvements
- code refactoring

## [1.4.0] 2017-11-02
### Library Updates
- jQuery - `3.2.1`
- bootstrap - `3.3.7`
- chartist - `0.11.0`

### Bug Fixing
- replaced old javascript checkboxes and radios with only css checkboxes and radios
- fixed responsive sidebar
- small bug fixes

## [1.3.1] 2017-01-19
- switched to MIT license

## [1.3] 2016-01-22
### New Template page + Video Tutorial [current version]
- added the default template page + youtube video tutorial on how to create an Admin Template (link: https://www.youtube.com/watch...)

## [1.2] 2016-01-17
### New Page
- for those who want to upsell inside their dashboard we added a new page "Upgrade to PRO" with a pricing and options table

## [1.1] 2015-09-08
### Bug Fixing
- added company name/logo inside the sidebar for small screens
- fixed bug for notification with close button on small screens
- fix live preview bug for download on small screens
- fix table responsive for small screens
- added new labels for chartist on small screens

## [1.0] 2015-08-20
### Initial Release
