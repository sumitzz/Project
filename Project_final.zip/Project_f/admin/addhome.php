<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST")			
{
$title=$_REQUEST['title'];
$fil=$_FILES['fil'];
	$product_pic=$fil['name'];
    $old=$fil['tmp_name'];
	$new="upload/".$product_pic;
	move_uploaded_file($old,$new);
$subtitle=$_REQUEST['subtitle'];
$spec=$_REQUEST['spec'];
$sql1="insert into home_tbl values(NULL,'".$title."','".$product_pic."','".$subtitle."','".$spec."')";
mysqli_query($cn,$sql1);
}
?>

<!=======================================DOCTYPE html=============================================>

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
 function validate()
      {
      
         if( document.f1.title.value == "" )
         {
            alert( "Please Provide Title!" );
            document.f1.title.focus() ;
            return false;
         }  
         var fileInput = document.getElementById("file");
         var filePath  = fileInput.value;
         var allowedExtensions= /(\.jpg|\.jpeg|\.png|\.gif)$/i;
         if(!allowedExtensions.exec(filePath))
         {
          alert( "Please Upload Image File!" );
          fileInput.value='';
          document.f1.fil.focus() ;
          return false;
         }
         if( document.f1.fil.value == "" )
         {
            alert( "Please Upload Picture!" );
            document.f1.fil.focus() ;
            return false;
         }  

         if( document.f1.subtitle.value == "" )
         {
            alert( "Please Provide Sub-Title!" );
            document.f1.subtitle.focus() ;
            return false;
         }
      
     if( document.f1.spec.value == "" )
         {
            alert( "Please Provide Specification!" );
            document.f1.spec.focus() ;
            return false;
         }  
  
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
         <script type="text/javascript">
            
        </script>  
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
<!========================================Form=========================================================>           <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal" method="post" action="" name="f1" onSubmit="return(validate());" enctype="multipart/form-data">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Add Home</h3>			
                        	       </div>
 <!========================================Form=========================================================>
 <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Title</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="title">
                 </div>
        </div>  
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Pic</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="file" type="file" name="fil">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Sub-Title</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="subtitle">
                 </div>
               </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Specification</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="spec">
                 </div>
        </div>
        
        
        
		   
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Save Data</button>                  
        
        
            
            
        </div> 
<!======================================================================================================>
                              
            
            </fieldset>
            </form>
        </div>   
                
   </div>  
                       
<!======================================================================================================>            
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
