<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$scat_name=$_REQUEST['scat_name'];
$category=$_REQUEST['category'];
$sql1="insert into subcategory_tbl values(NULL,'".$scat_name."','".$category."')";
mysqli_query($cn,$sql1);
}
?>

<!=======================================DOCTYPE html=============================================>

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
        <script>
 function validate()
      {
      
         if( document.f1.scat_name.value == "" )
         {
            alert( "Please Provide Sub-Category Name!" );
            document.f1.scat_name.focus() ;
            return false;
         }     
    
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
         <script type="text/javascript">
            
        </script>  
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
<!========================================Form=========================================================>           <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Add Sub-Categories Details</h3>			
                        	       </div>
 <!========================================Form=========================================================>
 <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Sub-Category Name</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="scat_name">
                 </div>
        </div>  
		
        <!--Design for combo box-->			 
			 
			 
			 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Category</strong></label>
                 <div class="controls">
                    <select id="selectError" name="category"> 
                     
                    <?php
                        $sql="select * from categories_tbl";
                        $rs=mysqli_query($cn,$sql);
                        while($data=mysqli_fetch_array($rs))
                        {
                          ?>
                        <option value="<?php echo $data['category_id'];?>">
                            <?php echo $data['category_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>       
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Save Data</button>                  
        
        
            
            
        </div> 
<!======================================================================================================>
                              
            
            </fieldset>
            </form>
        </div>   
                
   </div>  
                       
<!======================================================================================================>            
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
