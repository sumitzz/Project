<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$t1=$_REQUEST['t1'];
$details=$_REQUEST['details'];
$sql1="update about_tbl set title='".$t1."',details='".$details."' 
where about_id=".$did."";
mysqli_query($cn,$sql1);
}
$sql2 = "select * from about_tbl where about_id='".$did."'";
$rs = mysqli_query($cn,$sql2);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
        function goback()
        {
          window.history.back();
        }
 function validate()
      {
      
         if( document.f1.t1.value == "" )
         {
            alert( "Please Provide Title!" );
            document.f1.t1.focus() ;
            return false;
         }  
         if( document.f1.details.value == "" )
         {
            alert( "Please Provide Details!" );
            document.f1.details.focus() ;
            return false;
         } 
         return true;
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update About Details</h3>
                        	       </div>
  
          <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Title</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="t1" value="<?php echo $d['title'];?>">
                 </div>
        </div>

        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Details</strong></label>
                 <div class="controls">
                    <textarea name="details" id="inputError"><?php echo $d['details'];?></textarea>
                 </div>
        </div>

      
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Update Data</button>                  
        
        
            
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
            <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button>    
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
