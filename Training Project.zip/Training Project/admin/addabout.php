<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$t1=$_REQUEST['t1'];
$details=$_REQUEST['details'];
$sql1="insert into about_tbl values(NULL,'".$t1."','".$details."')";
mysqli_query($cn,$sql1);
}
?>

<!=======================================DOCTYPE html=============================================>

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
       <script>
 function validate()
      {
      
         if( document.f1.t1.value == "" )
         {
            alert( "Please Provide Title!" );
            document.f1.t1.focus() ;
            return false;
         }  
         if( document.f1.details.value == "" )
         {
            alert( "Please Provide Details!" );
            document.f1.details.focus() ;
            return false;
         } 
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
         <script type="text/javascript">
            
        </script>  
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
<!========================================Form=========================================================>           <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal" method="post" action="" name="f1" onSubmit="return(validate());">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Add About Details</h3>
                        	       </div>
 <!========================================Form=========================================================>
 <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Title</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="t1">
                 </div>
        </div>  
		
		 <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Details</strong></label>
                 <div class="controls">
                    <textarea name="details" class="input-xlarge focused" id="focusedInput"></textarea>
                 </div>
        </div>  
	
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Save Data</button>                  
        
        
            
            
        </div> 
<!======================================================================================================>
                              
            
            </fieldset>
            </form>
        </div>   
                
   </div>  
                       
<!======================================================================================================>            
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
