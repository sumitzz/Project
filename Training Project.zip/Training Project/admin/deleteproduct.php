<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
$id=$_REQUEST['did'];
$sql="delete from product_tbl where product_id='$id'";
mysqli_query($cn,$sql);
header("location:viewproduct.php");
?>