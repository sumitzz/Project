<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$product_name=$_REQUEST['name'];
$fil=$_FILES['fil'];
	$product_pic=$fil['name'];
    $old=$fil['tmp_name'];
	$new="upload/".$product_pic;
	move_uploaded_file($old,$new);
$product_spec=$_REQUEST['product_spec'];
$product_price=$_REQUEST['product_price'];
$scatid=$_REQUEST['scatid'];
$statusid=$_REQUEST['statusid'];
if($product_pic=="")
{
$sql="update product_tbl set product_name='".$product_name."',product_spec='".$product_spec."',product_price='".$product_price."',scat_id='".$scatid."',status_id='".$statusid."' where product_id=".$did."";
mysqli_query($cn,$sql);
}
else
{
$sql2="update product_tbl set product_name='".$product_name."',product_pic='".$product_pic."',product_spec='".$product_spec."',product_price='".$product_price."',scat_id='".$scatid."',status_id='".$statusid."' where product_id=".$did."";
mysqli_query($cn,$sql2);	
}
}
$sql1 = "select * from product_tbl where product_id='".$did."'";
$rs = mysqli_query($cn,$sql1);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
        function goback()
        {
          window.history.back();
        }
 function validate()
      {
      
         if( document.f1.name.value == "" )
         {
            alert( "Please Provide Product Name!" );
            document.f1.name.focus() ;
            return false;
         }
         if( document.f1.fil.value != "" )
         {
         
         var fileInput = document.getElementById("file");
         var filePath  = fileInput.value;
         var allowedExtensions= /(\.jpg|\.jpeg|\.png|\.gif)$/i;
         if(!allowedExtensions.exec(filePath))
         {
          alert( "Please Upload Image File!" );
          fileInput.value='';
          document.f1.fil.focus() ;
          return false;
         }
         }  
      
     if( document.f1.product_spec.value == "" )
         {
            alert( "Please Provide Product Specification!" );
            document.f1.product_spec.focus() ;
            return false;
         }
      if( document.f1.product_price.value == "" ||
         isNaN(parseFloat( document.f1.product_price.value )) ||
         document.f1.product_price.value.length > 8 )
         {
            alert( "Please Provide a Proper Price!" );
            document.f1.product_price.focus() ;
            return false;
         }       
  
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());" enctype="multipart/form-data">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update Product Details</h3>
                        	       </div>
  
          <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Name</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['product_name'];?>">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Pic</strong></label>
                 <div class="controls" align="left">
                        
              <label class="control-label" for="inputError"><strong>Old Pic &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <img src="upload\<?php echo $d['product_pic'];?>" height="200" width="200" /></strong></label>             
                     <br/>
                     <br/>
                     <br/>
                  &nbsp &nbsp &nbsp  <input class="input-xlarge focused" id="file" type="file" name="fil">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Specification</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="product_spec" value="<?php echo $d['product_spec'];?>">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Price</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="product_price" value="<?php echo $d['product_price'];?>">
                 </div>
        </div>
         <!--Design for combo box-->			 
			 
			 
			 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Sub-Category</strong></label>
                 <div class="controls">
                    <select id="selectError" name="scatid"> 
                     
                    <?php
                        $sql3="select * from subcategory_tbl";
                        $rs=mysqli_query($cn,$sql3);
                        while($data=mysqli_fetch_array($rs))
                        {
                          ?>
                        <option value="<?php echo $data['scat_id'];?>"<?php if($data['scat_id']==$d['scat_id']){?> 
                        selected="selected"<?php }?>>
                            <?php echo $data['scat_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>  
        <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Product Status</strong></label>
                 <div class="controls">
                    <select id="selectError" name="statusid"> 
                     
                    <?php
                        $sql1="select * from productstatus_tbl";
                        $rs1=mysqli_query($cn,$sql1);
                        while($data1=mysqli_fetch_array($rs1))
                        {
                          ?>
                        <option value="<?php echo $data1['status_id'];?>" <?php if($data1['status_id']==$d['status_id']){?> selected="selected"<?php }?>>
                            <?php echo $data1['status_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>     

        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Update Data</button>                  
        
        
            
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
          <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button>      
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
